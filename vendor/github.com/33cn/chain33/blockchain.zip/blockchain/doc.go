// Copyright Fuzamei Corp. 2018 All Rights Reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package blockchain

//区块链相关的模块：
//包括区块链的结构，区块链数据的存储
//接口设计：
